package com.efe.ecmod.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class EcModClient implements ClientModInitializer {
    private static KeyBinding keyBinding;
    private static boolean blockGui = false;
    private static long blockUntil = 0;

    @Override
    public void onInitializeClient() {
        keyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.ecmod.open",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_G,
                "category.ecmod"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (keyBinding.wasPressed()) {
                if (client.player != null) {
                    client.player.networkHandler.sendChatCommand("team ec");
                }
            }
            if (blockGui && System.currentTimeMillis() > blockUntil) {
                blockGui = false;
            }
        });
    }

    public static void blockGuiOpening() {
        blockGui = true;
        blockUntil = System.currentTimeMillis() + 1000;
    }

    public static boolean shouldBlockGui() {
        return blockGui;
    }
}