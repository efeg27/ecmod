package com.efe.ecmod;

import net.fabricmc.api.ModInitializer;

public class EcMod implements ModInitializer {
    public static final String MODID = "ecmod";

    @Override
    public void onInitialize() {
        System.out.println("[EC Mod] Yüklendi!");
    }
}